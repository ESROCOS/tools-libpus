/*
#include "C_ASN1_Types.h"
#include "pus_types.h"
#include "pus_error.h"

pusError_t example_function();

pusError_t example_function2();

pusError_t example_function3();
*/