/* This file was generated automatically: DO NOT MODIFY IT ! */

/* Declaration of the functions that have to be provided by the user */

#ifndef __USER_CODE_H_onboardapid__
#define __USER_CODE_H_onboardapid__

#include "C_ASN1_Types.h"

#ifdef __cplusplus
extern "C" {
#endif

void onboardapid_startup();

void onboardapid_PI_getApid(asn1SccPusApid *);

void onboardapid_PI_getSequenceCount(asn1SccPusSequenceCount *);

#ifdef __cplusplus
}
#endif


#endif
