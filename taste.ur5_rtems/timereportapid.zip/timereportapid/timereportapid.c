/* User code: This file will not be overwritten by TASTE. */

#include "timereportapid.h"

/* Function static data is declared in this file : */
#include "Context-timereportapid.h"

void timereportapid_startup()
{
    /* Write your initialization code here,
       but do not make any call to a required interface. */
}

void timereportapid_PI_getApid(asn1SccPusApid *OUT_apid)
{
    /* Write your code here! */
}

void timereportapid_PI_getSequenceCount(asn1SccPusSequenceCount *OUT_sequenceCount)
{
    /* Write your code here! */
}

